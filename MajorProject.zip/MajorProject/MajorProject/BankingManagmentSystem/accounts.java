package BankingManagmentSystem;
import java.sql.*;
import java.util.Random;

public class accounts {

    public long generateAccNum() {
        return 1000000000L + new Random().nextInt(900000000);
    }

    public boolean accExist(long accNo) throws Exception {
        Connection con = dbconnection.getConnection();
        PreparedStatement ps =
                con.prepareStatement("SELECT acc_no FROM accounts WHERE acc_no=?");
        ps.setLong(1, accNo);
        ResultSet rs = ps.executeQuery();
        return rs.next();
    }

    public long openAcc(int userId) throws Exception {
        Connection con = dbconnection.getConnection();
        long accNo;

        do {
            accNo = generateAccNum();
        } while (accExist(accNo));

        PreparedStatement ps = con.prepareStatement(
                "INSERT INTO accounts(acc_no,user_id,balance) VALUES(?,?,0)");
        ps.setLong(1, accNo);
        ps.setInt(2, userId);
        ps.executeUpdate();

        return accNo;
    }

    public long getAccNum(int userId) throws Exception {
        Connection con = dbconnection.getConnection();
        PreparedStatement ps =
                con.prepareStatement("SELECT acc_no FROM accounts WHERE user_id=?");
        ps.setInt(1, userId);
        ResultSet rs = ps.executeQuery();
        return rs.next() ? rs.getLong(1) : -1;
    }
}

