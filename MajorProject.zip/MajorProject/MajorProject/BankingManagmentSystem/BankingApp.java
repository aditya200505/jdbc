package BankingManagmentSystem;
import java.util.Scanner;

public class BankingApp {

    public static void main(String[] args) throws Exception {

        Scanner sc = new Scanner(System.in);
        User user = new User();
        accounts acc = new accounts();
        AccountManager manager = new AccountManager();

        System.out.println("1. Register\n2. Login");
        int choice = sc.nextInt();
        sc.nextLine();

        int userId = -1;

        if (choice == 1) {
            System.out.print("Username: ");
            String u = sc.nextLine();
            System.out.print("Password: ");
            String p = sc.nextLine();

            userId = user.register(u, p);
            if (userId != -1) {
                long accNo = acc.openAcc(userId);
                System.out.println("Account Created: " + accNo);
            }
        } else {
            System.out.print("Username: ");
            String u = sc.nextLine();
            System.out.print("Password: ");
            String p = sc.nextLine();
            userId = user.login(u, p);
        }

        if (userId == -1) return;

        long accNo = acc.getAccNum(userId);

        while (true) {
            System.out.println("\n1.Credit 2.Debit 3.Transfer 4.Balance 5.Exit");
            int ch = sc.nextInt();

            if (ch == 1)
                manager.creditMoney(accNo, sc.nextDouble());
            else if (ch == 2)
                manager.debitMoney(accNo, sc.nextDouble());
            else if (ch == 3)
                manager.transferMoney(accNo, sc.nextLong(), sc.nextDouble());
            else if (ch == 4)
                System.out.println("Balance: " + manager.checkBalance(accNo));
            else break;
        }
        sc.close();
    }
    
}