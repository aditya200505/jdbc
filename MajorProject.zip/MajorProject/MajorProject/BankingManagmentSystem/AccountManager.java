package BankingManagmentSystem;
import java.sql.*;

public class AccountManager {

    public double checkBalance(long accNo) throws Exception {
        Connection con = dbconnection.getConnection();
        PreparedStatement ps =
                con.prepareStatement("SELECT balance FROM accounts WHERE acc_no=?");
        ps.setLong(1, accNo);
        ResultSet rs = ps.executeQuery();
        return rs.next() ? rs.getDouble(1) : -1;
    }

    public void creditMoney(long accNo, double amount) throws Exception {
        Connection con = dbconnection.getConnection();
        PreparedStatement ps =
                con.prepareStatement(
                        "UPDATE accounts SET balance = balance + ? WHERE acc_no=?");
        ps.setDouble(1, amount);
        ps.setLong(2, accNo);
        ps.executeUpdate();
        System.out.println("Amount Credited Successfully");
    }

    public void debitMoney(long accNo, double amount) throws Exception {
        if (checkBalance(accNo) < amount) {
            System.out.println("Insufficient Balance");
            return;
        }

        Connection con = dbconnection.getConnection();
        PreparedStatement ps =
                con.prepareStatement(
                        "UPDATE accounts SET balance = balance - ? WHERE acc_no=?");
        ps.setDouble(1, amount);
        ps.setLong(2, accNo);
        ps.executeUpdate();
        System.out.println("Amount Debited Successfully");
    }

    public void transferMoney(long fromAcc, long toAcc, double amount)
            throws Exception {

        Connection con = dbconnection.getConnection();
        con.setAutoCommit(false);

        try {
            if (checkBalance(fromAcc) < amount) {
                System.out.println("Insufficient Balance");
                return;
            }

            PreparedStatement debit =
                    con.prepareStatement(
                            "UPDATE accounts SET balance=balance-? WHERE acc_no=?");
            PreparedStatement credit =
                    con.prepareStatement(
                            "UPDATE accounts SET balance=balance+? WHERE acc_no=?");

            debit.setDouble(1, amount);
            debit.setLong(2, fromAcc);

            credit.setDouble(1, amount);
            credit.setLong(2, toAcc);

            debit.executeUpdate();
            credit.executeUpdate();

            con.commit();
            System.out.println("Transfer Successful");

        } catch (Exception e) {
            con.rollback();
            System.out.println("Transaction Failed");
        }
    }
}
