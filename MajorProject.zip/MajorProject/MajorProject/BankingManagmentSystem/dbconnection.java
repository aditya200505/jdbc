package BankingManagmentSystem;
import java.sql.*;

public class dbconnection {
    static final String URL = "jdbc:mysql://localhost:3306/bankingdb";
    static final String USER = "root";
    static final String PASS = "Aditya123";

    public static Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(URL, USER, PASS);
    }
}