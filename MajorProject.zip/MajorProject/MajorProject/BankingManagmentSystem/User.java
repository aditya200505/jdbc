package BankingManagmentSystem;
import java.sql.*;

public class User {

    public int register(String username, String password) {
        try {
            Connection con = dbconnection.getConnection();
            PreparedStatement ps = con.prepareStatement("INSERT INTO users(username, password) VALUES(?, ?)", Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, username);
            ps.setString(2, password);
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1;
    }

    public int login(String username, String password) {
        try {
            Connection con = dbconnection.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT user_id FROM users WHERE username=? AND password=?");
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1;
    }
}
